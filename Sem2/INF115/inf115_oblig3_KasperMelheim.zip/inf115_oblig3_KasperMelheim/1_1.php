<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>1_1</title>
    <style>
      table {
        
      }
      td {
        padding: 3px;
      }
      th {
        padding: 3px;
      }
      </style>
    
  </head>
  <body>

<?php

echo '<h1>Good luck with the last compulsory!</h1>';

?>
  
  </body>
</html>