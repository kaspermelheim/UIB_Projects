package inf101.v20.gfx.gfxmode;

public enum Gravity {
	NORTH, NORTHWEST, WEST, SOUTHWEST, SOUTH, SOUTHEAST, EAST, NORTHEAST, CENTER
}
