package inf101.v20.rogue101;

public class Main {

	public static void main(String[] args) {
		RogueApplication.launch(args);
	}
}
