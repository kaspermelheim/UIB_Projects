package inf101.v20.rogue101.objects;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import inf101.v20.gfx.textmode.Printer;
import inf101.v20.grid.GridDirection;
import inf101.v20.grid.ILocation;
import inf101.v20.rogue101.RogueApplication;
import inf101.v20.rogue101.game.IGame;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
/**
 * En spiller i Rogue 101 
 * 
 * Spilleren navigerer labyrinten og slåss med monster. For å komme seg ut 
 * og vinne spille må spilleren gå gjennom portalen; for å åpne portalen 
 * må den finne amuletten og bære den med seg. 
 * 
 * På veien kan den plukke opp gull og slåss med monster
 * 
 * @author Anna Eilertsen - anna.eilertsen@uib.no
 *
 */
public class Player implements IPlayer {
	/**
	 * char representation of this type 
	 */
	public static final char SYMBOL = '@';
	private static final int MAXHEALTH = 100;
	private int attack;
	private int defence;
	private int damage;
	private int hp;
	private String name; 
	List<IItem> backpack = new ArrayList<IItem>();

	public Player() {
		attack = 10;
		defence = 2;
		damage = 3;
		hp = Player.MAXHEALTH;
		name = System.getProperty("user.name");
	}

	@Override
	public int getAttack() {
		return attack;
	}

	@Override
	public int getDamage() {
		return damage;
	}

	@Override
	public int getCurrentHealth() {
		return hp;
	}

	@Override
	public int getDefence() {
		return defence;
	}

	@Override
	public int getMaxHealth() {
		return Player.MAXHEALTH;
	}

	@Override
	public String getShortName() {
		return getLongName();
	}
	
	@Override
	public String getLongName() {
		return name;
	}

	@Override
	public int getSize() {
		return 5;
	}

	
	@Override
	public String getGraphicTextSymbol() {
		if (useEmoji()) {
			return Printer.coloured("🤴", Color.BLACK);  //🤴  ⚰️ "👸"
		} else {
			return "" + SYMBOL;
		}

	}

	private boolean useEmoji() {
		return false;
	}

	@Override
	public int handleDamage(int amount) {
		amount = Math.max(0, amount - defence);
		amount = Math.min(hp + 1, amount);
		hp -= amount;
		return amount;
	}

	@Override
	public void keyPressed(IGame game, KeyCode key) {
		System.err.println("Player moves");
		switch (key) {
		case A:
			tryToMove(game, GridDirection.WEST);
			break;
		case D:
			tryToMove(game, GridDirection.EAST);
			break;
		case W:
			tryToMove(game, GridDirection.NORTH);
			break;
		case S:
			tryToMove(game, GridDirection.SOUTH);
			break;
		case M:
			pickUp(game);
			break;
		case N:
			drop(game);
			break;
		default:
			System.err.printf("Illegal key pressed. Key: %s", key);
		}
		showStatus(game);
	}

	private void tryToMove(IGame game, GridDirection dir) {
		if (game.canGo(dir)) {
			game.displayDebug("Moving.");
			game.move(dir);
		} 
		else {
			if(game.attack(dir))
				game.displayDebug("Victory!");
			else
				game.displayDebug("Ouch! Can't go there.");
		}
	}

	//Print status
	public void showStatus(IGame game) {
		
		if(backpack.size() == 0) {
			game.displayMessage("Player has " + this.hp + " hp left and backpack is empty.");
		}
		else {
			game.displayMessage("Player has " + this.hp + " hp left and backpack contains " + toString(backpack));
		}
	}
	
	//Laget toString metode for å printe ut innhold i backpack
	public String toString(List<IItem> liste) {
		String items = "";
		for(IItem item : liste) {
			items += item.getShortName() + ", ";
		}
		return items;
	}

	/**
	 * 
	 * Lager en ny liste øverst i klassen "backpack". Henter så det itemet player står på og plasserer
	 * det i lista pickups. Om pickups er tom har vi ikke funnet et item vi kan plukke opp, og metoden skal stoppe.
	 * Om lista har et element legger vi det til backpack i første pos.  
	 * @param game
	 */
	public void pickUp(IGame game) {
		
		List<IItem> pickups = game.getLocalNonActorItems();
		if(pickups.size() == 0) {
			return;
		}
		
		game.pickUp(pickups.get(0));
		backpack.add(pickups.get(0));
		game.displayMessage("Picked up: " + pickups.get(0).getShortName());
		
	}

	/**
	 * Metode som første sjekker om backpack er tom, dersom ikke skal den kaste ut første elementet i backpack
	 * (index o), og skrive ut melding.
	 * @param game
	 */
	public void drop(IGame game) {
		if(backpack.isEmpty()) {
			game.displayMessage("Your backpack is empty!");
		}
		
		if(game.drop(backpack.get(0))) {
			game.displayMessage("Dropped " + backpack.get(0).getShortName());
			backpack.remove(0);
		}
		else {
			game.displayMessage("Item cannot be dropped"); 
		}
	}

	@Override
	public void doTurn(IGame game) {
	}
	
	@Override 
	public boolean isDestroyed() {
		return false; //Even when dead, the player should remain on the map
	}

	/**
	 * Bruker .contains(item) for å sjekke om lista inneholder itemet vi som blir spurt etter. Dersom ja
	 * return true.
	 */
	@Override
	public boolean hasItem(IItem item) {
		if(backpack.contains(item)) {
			return true;
		}
		return false;
	}
	
	@Override
	public char getSymbol() {
		return SYMBOL;
	}
}
