# Authors

* Anya Helene Bagge, UiB  (graphics, maintenance)
* Lars Jaffke, UiB (Langton's Ant)
* *you*, UiB (the rest!)
 