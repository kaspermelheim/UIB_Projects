# INF142-Mandatory-Group49
Repository for the first mandatory assignment in INF142

#How to start the program

1. Make sure you are in the correct working directory. (INF142-Mandatory-Group49/station folder)
2. Run storage.py in cmd (starts the server)
3. Run station_sender.py in cmd (retrives data from station.py and sends it to storage.py)
4. Run FMI.py in cmd and follow instructions.

MVP covered + 2 bonus tasks (MongoDB and GUI (FMI.py))