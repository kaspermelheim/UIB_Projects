import tkinter as tk
from tkinter import *
import os

#Standard tkinter code for displaying a window in python with buttons, frames etc.
root = tk.Tk()

#Add image file
bg = PhotoImage(file = "sky.png")

#Run our client file
def runApp():
    os.startfile("user.py")

#End tkinter app
def end():
    root.destroy()

#New canvas
canvas = tk.Canvas(root, height = 500, width = 600, bg="white")

#Create image
canvas.create_image( 0, 0, image = bg, 
                     anchor = "nw")                
canvas.pack(fill = "both", expand = True)

#Create frame
frame = tk.Frame(root, bg="white")
frame.place(relwidth=0.8, relheight=0.8, relx=0.1, rely=0.05)

#Create start program button
runApp = tk.Button(frame, text = "Start Program", padx=10, pady=5, fg= "white", bg="#86ADB6", command = runApp)
runApp.place(x=200, y=200)

#Create quit button
end = tk.Button(frame, text = "Quit", padx=10, pady=5, fg= "white", bg="#86ADB6", command = end)
end.place(x=225, y=235)

#Add informative text
label = tk.Label(frame, text = "Fictional Meteorological Institute",bg="white",padx=10, pady=5,  font=("Arial",16))
label.pack()
label1 = tk.Label(frame, text = "Welcome to the FMI client! Here you can launch the \nprogram for retrieving weatherdata from the storage.\n\nCreate more users by starting multiple programs.",bg="white",padx=5, pady=5, font=("Arial", 12))
label1.pack()

#Loop
root.mainloop()