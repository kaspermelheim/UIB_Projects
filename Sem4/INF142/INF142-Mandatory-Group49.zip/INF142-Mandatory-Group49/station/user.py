#Import socket
from socket import socket, AF_INET, SOCK_DGRAM

from time import sleep

#New socket
sock = socket(AF_INET, SOCK_DGRAM)

print("--| Commands |--")
print("1. GET - retrieve all weatherdata")
print("2. END - end program")

#Check inputs from users
while ((text := input('> ').lower()) != "shut down"):
    if(text == "get"):
        sock.sendto(text.encode(), ("localhost", 55555))
        msg, addr = sock.recvfrom(2048)
        print()
        print("Server")
        sleep(1)
        print("  |  ")
        sleep(1)
        print("  |  ")
        sleep(1)
        print("  V  ")
        sleep(1)
        print(" User")
        sleep(1)

        print()
        print("Retrieved data: \n")
        print(msg.decode())
    elif(text == "end"):
        print("Bye!")
        break
    else:
        print("Unknown command. Type 'GET' to retrieve all data.")