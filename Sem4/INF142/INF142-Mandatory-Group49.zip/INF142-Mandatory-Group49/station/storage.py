#Import socket and datetime
from socket import socket, AF_INET, SOCK_DGRAM
from datetime import datetime
from time import sleep
from station import StationSimulator

#New socket and bind
sock = socket(AF_INET, SOCK_DGRAM)
sock.bind(("localhost", 55555))

print("Storage Status: Running...")

while True:
    msg, addr = sock.recvfrom(2048)
    text = msg.decode()

    if (text != "get"):
        with open("WeatherData.txt", "w") as file:
            file.write(text)
        print(f"Storage Status: Receving weatherdata from {addr[0]}: {msg.decode()}")
    else: 
        #Opens a file and reads from it
        with open("WeatherData.txt", 'r') as file:
            data = file.read()
        print(f"{addr[0]} sent command: {msg.decode()}")
        sock.sendto((data.encode()), addr)