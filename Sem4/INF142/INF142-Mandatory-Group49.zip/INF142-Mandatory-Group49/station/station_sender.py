from socket import socket, AF_INET, SOCK_DGRAM
from datetime import datetime
from time import sleep
from station import StationSimulator

sock = socket(AF_INET, SOCK_DGRAM)

bergen_station = StationSimulator(simulation_interval=1)
    # Turn on the simulator
bergen_station.turn_on()

    # Two lists for temperature and precipitation
temperature = []
precipitation = []

print("Station-Sender Status: fetching weatherdata from Station and sending to Storage...")
    # Capture data for 72 hours
    # Note that the simulation interval is 10 seconds
for _ in range(10):
        # Sleep for 1 second to wait for new weather data
        # to be simulated
    sleep(1)
        # Read new weather data and append it to the
        # corresponding list
    temperature.append(bergen_station.temperature)
    precipitation.append(bergen_station.rain)

    tempStr = ', '.join([str(elem) for elem in temperature])
    rainStr = ', '.join([str(elem) for elem in precipitation])

    data = f"Temperature (C): {tempStr} \nRain (mm): {rainStr}"

    sock.sendto(data.encode(), ("localhost", 55555))

    # Shut down the simulation
bergen_station.shut_down()
print("Station-Sender Status: finished sending data: " + str(data) + " to Storage.")
sock.close()