# -*- coding: utf-8 -*-
"""
Created on Wed Aug 21 18:05:18 2019

@author: Kasper
"""

# 1.a

h = 'Hello'
w = 'World'
print(h + ' ' + w)

# 1.b

x = 10
y = 5
sum1 = (x * y)/2
print(sum)

print(4 + 3 * 7)

# 2.a

kurs_usd = 8.57
headset_pris_nok = 1500
# Bruker "//" for å fjerne uendelige desimaler
headset_pris_usd = headset_pris_nok // kurs_usd
print(headset_pris_usd)

#2.b

var1 = "Mitt navn er "
navn = "Kasper"
var2 = var1 + navn + "."
print(var2)